# CTG Dataset (repo plantilla)

Este repositorio contiene el archivo `Data/CTG.csv` listo para ser consumido desde pandas vía `raw.githubusercontent.com`.

## Pasos para publicarlo en tu GitHub

1. Crea un repositorio vacío en tu cuenta de GitHub (público si deseas usar `pd.read_csv` sin token).
2. En tu máquina, ejecuta:

```bash
git init
git remote add origin https://github.com/TU_USUARIO/TU_REPO.git
git branch -M main
git add .
git commit -m "Add CTG dataset and sample loader"
git push -u origin main
```

## URL crudo (raw)

Una vez empujado, la URL típica será:

```
https://raw.githubusercontent.com/TU_USUARIO/TU_REPO/main/Data/CTG.csv
```

## Carga desde pandas

```python
import pandas as pd
url = "https://raw.githubusercontent.com/TU_USUARIO/TU_REPO/main/Data/CTG.csv"
df = pd.read_csv(url)
```

### Repositorio privado
Si el repo es **privado**, necesitarás autenticación. Ejemplo con `requests`:

```python
import os, io, requests, pandas as pd

GITHUB_TOKEN = os.getenv("GITHUB_TOKEN")  # o coloca el token directamente (no recomendado)
url = "https://raw.githubusercontent.com/TU_USUARIO/TU_REPO/main/Data/CTG.csv"
headers = {"Authorization": f"token {GITHUB_TOKEN}"}
r = requests.get(url, headers=headers)
r.raise_for_status()
df = pd.read_csv(io.StringIO(r.text))
```