# Cargar el conjunto de datos desde TU GitHub
# Reemplaza TU_USUARIO y TU_REPO por los nombres reales
import pandas as pd

url = "https://raw.githubusercontent.com/TU_USUARIO/TU_REPO/main/Data/CTG.csv"
df = pd.read_csv(url)

print(df.head())