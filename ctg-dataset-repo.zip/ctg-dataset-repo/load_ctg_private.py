# Ejemplo de carga desde repositorio privado usando token
import os, io, requests, pandas as pd

# Establece tu token en la variable de entorno GITHUB_TOKEN
# o coloca el valor directamente en la variable (menos seguro)
GITHUB_TOKEN = os.getenv("GITHUB_TOKEN")

url = "https://raw.githubusercontent.com/TU_USUARIO/TU_REPO/main/Data/CTG.csv"
headers = {"Authorization": f"token {GITHUB_TOKEN}"} if GITHUB_TOKEN else {}

r = requests.get(url, headers=headers)
r.raise_for_status()

df = pd.read_csv(io.StringIO(r.text))
print(df.head())